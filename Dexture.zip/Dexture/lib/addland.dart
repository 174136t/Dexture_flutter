import 'package:flutter/material.dart';
import 'package:scoped_model/scoped_model.dart';
import 'widjets/location_input_form.dart';
import 'scoped_models/main_model.dart';

class Addland extends StatefulWidget {
  @override
  _AddlandState createState() => _AddlandState();
}

class _AddlandState extends State<Addland> {
  @override
  Widget build(BuildContext context) {
    return ScopedModelDescendant<MainModel>(
      builder: (BuildContext context, Widget child, MainModel model) {
        return Scaffold(
          backgroundColor: Colors.blue[600],
          body: Container(
            decoration: BoxDecoration(
                color: Colors.blue[100],
                borderRadius:
                    BorderRadius.only(topLeft: Radius.circular(230.0))),
            child: Column(
              children: <Widget>[
                LocationInputFormField(model),
              ],
            ),
          ),
        );
      },
    );
  }
}
