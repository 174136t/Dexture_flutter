import 'package:scoped_model/scoped_model.dart';
import './map_model.dart';

class MainModel extends Model with LocationModel {}
