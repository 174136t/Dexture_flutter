import 'package:flutter/material.dart';

class Viewland extends StatefulWidget {
  @override
  _ViewlandState createState() => _ViewlandState();
}

class _ViewlandState extends State<Viewland> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
              backgroundColor: Colors.blue[600],
          body: Container(
         decoration: BoxDecoration(
                color: Colors.blue[100],
                borderRadius: BorderRadius.only(topLeft: Radius.circular(230.0))),
      ),
    );
  }
}