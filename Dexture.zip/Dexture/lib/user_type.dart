// import 'package:flutter/material.dart';

// //import 'package:path/path.dart';
// import 'farmerhome.dart';
// import 'officerhome.dart';

// //import 'package:flutter/services.dart';

// class UserTypePage extends StatefulWidget {
//   @override
//   _UserTypePageState createState() => new _UserTypePageState();
// }

// class _UserTypePageState extends State<UserTypePage> {
//   //int _bottomNavIndex=0;
//   @override
//   Widget build(BuildContext context) {
//     return new Scaffold(
//       appBar: new AppBar(
//         backgroundColor: Colors.brown,
//         elevation: 0.0,
//         title: Text('Select user type'),
//         centerTitle: true,
//         // iconTheme: new IconThemeData(color: Color(0xFF18D191)
//         // )
//       ),
//       body: Container(
//         decoration: BoxDecoration(
//           gradient: new LinearGradient(
//             colors: [const Color(0xFFBCAAA4), const Color(0xFFA1887F)],
//             begin: FractionalOffset.topLeft,
//             end: FractionalOffset.bottomRight,
//           ),
//         ),
//         padding: EdgeInsets.all(10.0),
//         child: Center(
//           child: Container(
//             // width: targetWidth,
//             child: Form(
//               //  key: _formKey,
//               child: Center(
//                 child: SingleChildScrollView(
//                   child: Column(
//                     // padding: EdgeInsets.only(left: 5.0, right: 5.0),
//                     children: <Widget>[
//                       new Row(
//                         mainAxisAlignment: MainAxisAlignment.center,
//                         children: <Widget>[
//                           Expanded(
//                             child: Padding(
//                               padding: const EdgeInsets.only(
//                                   left: 0.0, right: 10.0, top: 0.0),
//                               child: GestureDetector(
//                                 onTap: () {
//                                   Navigator.push(
//                                       context,
//                                       MaterialPageRoute(
//                                         builder: (context) => HomePage(),
//                                       ));
//                                 },
//                                 child: new Container(
//                                     alignment: Alignment.center,
//                                     height: 40.0,
//                                     decoration: new BoxDecoration(
//                                         color: Colors.brown,
//                                         borderRadius:
//                                             new BorderRadius.circular(9.0)),
//                                     //child:new Icon(Icons.lightbulb_outline),
//                                     child: new Text("Buyer",
//                                         style: new TextStyle(
//                                             fontSize: 19.0,
//                                             color: Colors.white))),
//                               ),
//                             ),
//                           ),
//                         ],
//                       ),
//                       SizedBox(height: 30.0),
//                       new Row(
//                         mainAxisAlignment: MainAxisAlignment.center,
//                         children: <Widget>[
//                           Expanded(
//                             child: Padding(
//                               padding: const EdgeInsets.only(
//                                   left: 0.0, right: 10.0, top: 0.0),
//                               child: GestureDetector(
//                                 onTap: () {
//                                   Navigator.push(
//                                       context,
//                                       MaterialPageRoute(
//                                         builder: (context) => HomePage(),
//                                       ));
//                                 },
//                                 child: new Container(
//                                     alignment: Alignment.center,
//                                     height: 40.0,
//                                     decoration: new BoxDecoration(
//                                         color: Colors.brown,
//                                         borderRadius:
//                                             new BorderRadius.circular(9.0)),
//                                     //child:new Icon(Icons.lightbulb_outline),
//                                     child: new Text("Farmer",
//                                         style: new TextStyle(
//                                             fontSize: 19.0,
//                                             color: Colors.white))),
//                               ),
//                             ),
//                           ),
//                         ],
//                       ),
//                       SizedBox(height: 30.0),
//                       new Row(
//                         mainAxisAlignment: MainAxisAlignment.center,
//                         children: <Widget>[
//                           Expanded(
//                             child: Padding(
//                               padding: const EdgeInsets.only(
//                                   left: 0.0, right: 10.0, top: 0.0),
//                               child: GestureDetector(
//                                 onTap: () {
//                                   Navigator.push(
//                                       context,
//                                       MaterialPageRoute(
//                                         builder: (context) => DevHomePage(),
//                                       ));
//                                 },
//                                 child: new Container(
//                                     alignment: Alignment.center,
//                                     height: 40.0,
//                                     decoration: new BoxDecoration(
//                                         color: Colors.brown,
//                                         borderRadius:
//                                             new BorderRadius.circular(9.0)),
//                                     //child:new Icon(Icons.lightbulb_outline),
//                                     child: new Text("Officer",
//                                         style: new TextStyle(
//                                             fontSize: 19.0,
//                                             color: Colors.white))),
//                               ),
//                             ),
//                           ),
//                         ],
//                       ),
//                     ],
//                   ),
//                 ),
//               ),
//             ),
//           ),
//         ),
//       ),
//     );
//   }
// }
